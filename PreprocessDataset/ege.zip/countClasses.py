import os

label_list = os.listdir(os.path.join(os.getcwd(),"labels"))


human_count = 0 
vehicle_count = 0
drone_count = 0
airplane_count = 0 
helicopter_count = 0 
bird_count =  0
for i in label_list:
    human_count_per_txt = 0
    vehicle_count_per_txt = 0
    drone_count_per_txt = 0
    airplane_count_per_txt = 0
    helicopter_count_per_txt = 0
    bird_count_per_txt = 0
    with open(os.path.join(os.getcwd(),"labels",i),"r+") as r:

        text = r.read()
        text_split = text.split("\n")

        if text_split[-1] == "":
            text_split.pop()

        for k in text_split:
            split_i = k.split(" ")
            if split_i[0] == "0":
                human_count_per_txt+=1
            if split_i[0] == "1":
                vehicle_count_per_txt+=1
            if split_i[0] == "2":
                drone_count_per_txt+=1
            if split_i[0] == "3":
                airplane_count_per_txt+=1
            if split_i[0] == "4":
                helicopter_count_per_txt+=1
            if split_i[0] == "5":
                bird_count_per_txt+=1

    if (human_count_per_txt > 0):
        human_count+=1
    elif (vehicle_count_per_txt > 0):
        vehicle_count+=1
    elif (drone_count_per_txt > 0):
        drone_count+=1
    elif (airplane_count_per_txt > 0):
        airplane_count += 1
    elif (helicopter_count_per_txt > 0):
        helicopter_count += 1
    elif (bird_count_per_txt > 0):
        bird_count += 1


    human_count_per_txt = 0
    vehicle_count_per_txt = 0
    drone_count_per_text = 0
    airplane_count_per_txt = 0
    helicopter_count_per_txt = 0
    bird_count_per_txt = 0

print("Coco 2017 Dataset - Valid Images Contains\n<------------------------------------------->\n"
      "Human : {}\nVehicle : {}\nDrone : {}\nAirplane : {}\nHelicopter : {}\nBird : {}\n---------------------------------------------\n".format(human_count,vehicle_count,drone_count,airplane_count,helicopter_count,bird_count))
