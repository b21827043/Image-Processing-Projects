import os

image_path = os.path.join(os.getcwd(),"images")
label_path = os.path.join(os.getcwd(),"labels")


# Function to rename multiple files
def main():
	i = 60000
	
	for filename in os.listdir(image_path):
		my_dest ="heli" + str(i) + ".jpg"
		my_source = os.path.join(image_path,filename)
		my_dest = os.path.join(image_path,my_dest)
		# rename() function will
		# rename all the files
		
		temp = filename.split(".")[0]
		label_source = os.path.join(label_path,temp + ".txt")
		label_dest = os.path.join(label_path,"heli" + str(i)+ ".txt")
		
		os.rename(my_source, my_dest)
		os.rename(label_source,label_dest)
		i += 1
# Driver Code
if __name__ == '__main__':
	# Calling main() function
	main()
